import java.util.List;

public interface Base {
	
	public List<Object> Buscar();
	
	public Object Adicionar();
	
	public void Remover();
	
	public void Atualizar();
}
